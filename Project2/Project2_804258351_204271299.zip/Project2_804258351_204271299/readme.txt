The project2.ipynb contains all of the code for this project. To obtain the results, you can just run down all the cells from top to bottom. Each section is annotated with what it corresponds to.
